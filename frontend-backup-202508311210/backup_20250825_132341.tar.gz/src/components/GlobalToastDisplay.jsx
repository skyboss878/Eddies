import React from 'react';

// This component is not needed since toast.js handles display directly
// But keeping it for compatibility
const GlobalToastDisplay = () => {
  return null; // toast.js handles display via direct DOM manipulation
};

export default GlobalToastDisplay;
