import React from 'react'
import MobileTechApp from '../components/mobile/MobileTechApp'

const Mobile: React.FC = () => {
  return <MobileTechApp />
}

export default Mobile
