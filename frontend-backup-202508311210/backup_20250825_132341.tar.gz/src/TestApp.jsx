import React from 'react';

const TestApp = () => {
  return (
    <div style={{
      padding: '20px',
      backgroundColor: '#f0f0f0',
      minHeight: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <h1 style={{ color: '#333' }}>🚗 Eddie's Askan Automotive</h1>
      <p style={{ color: '#666' }}>Test app is working!</p>
      <p>If you see this, React is rendering correctly.</p>
    </div>
  );
};

export default TestApp;
