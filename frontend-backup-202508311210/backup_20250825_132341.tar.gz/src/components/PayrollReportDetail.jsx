// ./src/components/PayrollReportDetail.jsx
import React from 'react';

const PayrollReportDetail = () => (
  <div>
    <h1>Payroll Report Detail</h1>
  </div>
);

export default PayrollReportDetail;
