// src/App.jsx - Version without QueryClientProvider (handled by CombinedProviders)
import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Import components
import EstimateAI from './pages/EstimateAI';
import ProtectedRoute from './components/ProtectedRoute';
import LoadingSpinner from './components/LoadingSpinner';
import Layout from './components/Layout';

// Lazy load pages for better performance
const Landing = lazy(() => import('./pages/Landing'));
const Login = lazy(() => import('./pages/Login'));
const Register = lazy(() => import('./pages/Register'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Customers = lazy(() => import('./pages/Customers'));
const CustomerDetail = lazy(() => import('./pages/CustomerDetail'));
const AddAndEditCustomer = lazy(() => import('./pages/AddAndEditCustomer'));
const Vehicles = lazy(() => import('./pages/Vehicles'));
const VehicleDetail = lazy(() => import('./pages/VehicleDetail'));
const VehicleForm = lazy(() => import('./pages/VehicleForm'));
const AddVehicle = lazy(() => import('./pages/AddVehicle'));
const Jobs = lazy(() => import('./pages/Jobs'));
const JobDetail = lazy(() => import('./pages/JobDetail'));
const CreateJob = lazy(() => import('./pages/CreateJob'));
const ViewJobs = lazy(() => import('./pages/ViewJobs'));
const Estimates = lazy(() => import('./pages/Estimates'));
const EstimateDetail = lazy(() => import('./pages/EstimateDetail'));
const CreateEditEstimate = lazy(() => import('./pages/CreateEditEstimate'));
const Invoices = lazy(() => import('./pages/Invoices'));
const Invoice = lazy(() => import('./pages/Invoice'));
const Inventory = lazy(() => import('./pages/Inventory'));
const PartsLaborManagement = lazy(() => import('./pages/PartsLaborManagement'));
const AppointmentCalendar = lazy(() => import('./pages/AppointmentCalendar'));
const TimeClock = lazy(() => import('./pages/TimeClock'));
const AIDiagnostics = lazy(() => import('./pages/AIDiagnostics'));
const Diagnosis = lazy(() => import('./pages/Diagnosis'));
const Reports = lazy(() => import('./pages/Reports'));
const Settings = lazy(() => import('./pages/Settings'));
const DataMigration = lazy(() => import('./pages/DataMigration'));
const Mobile = lazy(() => import('./pages/Mobile'));
const NotFound = lazy(() => import('./pages/NotFound'));

// Loading component
const AppLoading = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <LoadingSpinner />
  </div>
);

function App() {
  return (
    <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <div className="App min-h-screen bg-gray-50">
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />

        <Suspense fallback={<AppLoading />}>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/mobile" element={<Mobile />} />

            {/* Protected routes - wrapped in Layout */}
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Customer Management */}
            <Route path="/customers" element={
              <ProtectedRoute>
                <Layout>
                  <Customers />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/customers/new" element={
              <ProtectedRoute>
                <Layout>
                  <AddAndEditCustomer />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/customers/:id" element={
              <ProtectedRoute>
                <Layout>
                  <CustomerDetail />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/customers/:id/edit" element={
              <ProtectedRoute>
                <Layout>
                  <AddAndEditCustomer />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Vehicle Management */}
            <Route path="/vehicles" element={
              <ProtectedRoute>
                <Layout>
                  <Vehicles />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/vehicles/new" element={
              <ProtectedRoute>
                <Layout>
                  <AddVehicle />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/vehicles/:id" element={
              <ProtectedRoute>
                <Layout>
                  <VehicleDetail />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/vehicles/:id/edit" element={
              <ProtectedRoute>
                <Layout>
                  <VehicleForm />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Job Management */}
            <Route path="/jobs" element={
              <ProtectedRoute>
                <Layout>
                  <Jobs />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/jobs/new" element={
              <ProtectedRoute>
                <Layout>
                  <CreateJob />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/jobs/create" element={
              <ProtectedRoute>
                <Layout>
                  <CreateJob />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/jobs/:id" element={
              <ProtectedRoute>
                <Layout>
                  <JobDetail />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/jobs/view" element={
              <ProtectedRoute>
                <Layout>
                  <ViewJobs />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Estimates */}
            <Route path="/estimates" element={
              <ProtectedRoute>
                <Layout>
                  <Estimates />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/estimates/new" element={
              <ProtectedRoute>
                <Layout>
                  <CreateEditEstimate />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/estimates/create" element={
              <ProtectedRoute>
                <Layout>
                  <CreateEditEstimate />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/estimates/:id" element={
              <ProtectedRoute>
                <Layout>
                  <EstimateDetail />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/estimates/:id/edit" element={
              <ProtectedRoute>
                <Layout>
                  <CreateEditEstimate />
                </Layout>
              </ProtectedRoute>
            } />
            
            {/* Invoices */}
            <Route path="/invoices" element={
              <ProtectedRoute>
                <Layout>
                  <Invoices />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/invoices/:id" element={
              <ProtectedRoute>
                <Layout>
                  <Invoice />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Inventory & Parts */}
            <Route path="/inventory" element={
              <ProtectedRoute>
                <Layout>
                  <Inventory />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/parts-labor" element={
              <ProtectedRoute>
                <Layout>
                  <PartsLaborManagement />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Appointments */}
            <Route path="/appointments" element={
              <ProtectedRoute>
                <Layout>
                  <AppointmentCalendar />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Time Clock */}
            <Route path="/timeclock" element={
              <ProtectedRoute>
                <Layout>
                  <TimeClock />
                </Layout>
              </ProtectedRoute>
            } />

            {/* AI Features */}
            <Route path="/ai-diagnostics" element={
              <ProtectedRoute>
                <Layout>
                  <AIDiagnostics />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/diagnosis" element={
              <ProtectedRoute>
                <Layout>
                  <Diagnosis />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Reports - Manager/Admin only */}
            <Route path="/reports" element={
              <ProtectedRoute requiredRole="manager">
                <Layout>
                  <Reports />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Settings - Admin only */}
            <Route path="/settings" element={
              <ProtectedRoute requiredRole="admin">
                <Layout>
                  <Settings />
                </Layout>
              </ProtectedRoute>
            } />

            {/* Data Migration - Admin only */}
            <Route path="/data-migration" element={
              <ProtectedRoute requiredRole="admin">
                <Layout>
                  <DataMigration />
                </Layout>
              </ProtectedRoute>
            } />

            {/* 404 page */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </div>
    </Router>
  );
}

export default App;
