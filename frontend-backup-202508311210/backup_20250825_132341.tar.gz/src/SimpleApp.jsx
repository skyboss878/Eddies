import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';

// Simple fallback pages
const Landing = () => (
  <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center">
    <div className="text-center">
      <h1 className="text-4xl font-bold text-gray-900 mb-4">Eddie's Automotive</h1>
      <p className="text-xl text-gray-600 mb-8">Professional Auto Repair Management</p>
      <div className="space-x-4">
        <a href="/login" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">Login</a>
        <a href="/register" className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700">Register</a>
      </div>
    </div>
  </div>
);

const Login = () => (
  <div className="min-h-screen bg-gray-50 flex items-center justify-center">
    <div className="max-w-md w-full bg-white p-8 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-6">Login</h2>
      <div className="space-y-4">
        <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" />
        <input type="password" placeholder="Password" className="w-full p-3 border rounded-lg" />
        <button className="w-full bg-blue-600 text-white p-3 rounded-lg">Sign In</button>
      </div>
    </div>
  </div>
);

const Dashboard = () => (
  <div className="p-8">
    <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold text-gray-700">Jobs</h3>
        <p className="text-3xl font-bold text-blue-600">12</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-lg font-semibold text-gray-700">Customers</h3>
        <p className="text-3xl font-bold text-green-600">284</p>
      </div>
    </div>
  </div>
);

const SimpleApp = () => {
  return (
    <AuthProvider>
      <DataProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="*" element={<div className="p-8"><h1>404 - Not Found</h1></div>} />
          </Routes>
          <Toaster position="top-right" />
        </Router>
      </DataProvider>
    </AuthProvider>
  );
};

export default SimpleApp;
